#include <iostream>
#include "interface.h"

using namespace std;

int main()
{
    Interface program;
    program.start();

    return 0;
}
