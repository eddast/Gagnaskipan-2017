#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <string>
#include <iostream>
using namespace std;

class EmptyException{};

template <class T>
struct Node
{
    T data;
    Node<T>* next;

    Node() : data(), next(NULL) { }
    Node(T val, Node *next = NULL)
    : data(val), next(next) { }
};

template <class T>
class LinkedList
{
    public:
        LinkedList()
        {
            // Only one node because list is singly linked
            head = new Node<T>();
            // Nothing in list besides head
            size = 0;
        }

        virtual ~LinkedList()
        {
            clearList();
            delete head;
            head = NULL;
        }

        void tailInsert(T value)
        {
            // The new node created and assigned it's value
            Node<T>* newNode = new Node<T>;
            newNode->data = value;
            newNode->next = NULL;
            // Temp created that points to head
            Node<T>* tempNode = head;

            if(!isEmpty())
            {
                // Iterate to end of list
                while (tempNode->next != NULL)
                {
                    tempNode = tempNode->next;
                }

                // Last element set to new node
                tempNode->next = newNode;
            }
            // For an empty list, new node set besides head
            else
            {
                head->next = newNode;
            }
            // Size naturally increases by one
            size++;
        }

        void headInsert(T value)
        {
            Node<T>* newNode = new Node<T>;
            newNode->data = value;

            newNode->next = head->next;
            head->next = newNode;

            size++;
        }

        T headRemove()
        {
            checkEmpty();

            Node<T>* tempPtr = new Node<T>;
            tempPtr = head->next;

            T removedVal = tempPtr->data;

            head->next = tempPtr->next;

            delete tempPtr;

            size--;

            return removedVal;
        }

        void clearList()
        {
            if(!isEmpty())
            {
                Node<T>* tempPtr = head->next;
                while(tempPtr != NULL)
                {
                    head->next = tempPtr->next;
                    delete tempPtr;
                    tempPtr = head->next;
                }
                size = 0;
            }
        }

        friend ostream& operator <<(ostream& outs, LinkedList<T>& lis)
        {
            // New node as first node
            Node<T>* node = lis.head->next;
            while(node != NULL){
                // Outputs data of nodes while iterating through list
                outs << node->data;
                if (node->next != NULL)
                {
                    outs << " ";
                }
                node = node->next;
            }
            return outs;
        }

    private:
        Node<T>* head;
        int size;
        bool isEmpty()
        {
            return size == 0;
        }

        void checkEmpty()
        {
            if(isEmpty())
            {
                throw EmptyException();
            }
        }
};

#endif // LINKEDLIST_H
