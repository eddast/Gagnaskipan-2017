#ifndef HASH_H
#define HASH_H
#include "StringContactMap.h"
#include <string>

using namespace std;

unsigned int hash_value(string s);

#endif
