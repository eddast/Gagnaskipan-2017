#include <iostream>
#include "InteractivePhoneBook.h"

int main()
{
    InteractivePhoneBook pb;
    pb.start();
}

