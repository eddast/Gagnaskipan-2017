#ifndef KEYEXCEPTION_H
#define KEYEXCEPTION_H value

class KeyException { };

#endif
