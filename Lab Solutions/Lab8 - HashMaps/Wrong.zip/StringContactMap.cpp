#include "StringContactMap.h"
#include "Hash.h"
#include <algorithm>

using namespace std;

StringContactMap::StringContactMap(int initial_capacity)
{
    // Capacity set to initial capacity and map created
    // Count is zero since map contains no elements
    // Initialize all "buckets" with empty ContactLists
    capacity = initial_capacity;
    map = new ListPtr[capacity];
    for(int i = 0; i < capacity; i++)
    {
        // Setting all elements to zero
        map[i] = NULL;
    }
    count = 0;
}

StringContactMap::~StringContactMap()
{
    delete_map(map);
}

void StringContactMap::load_check()
{
    // Checks if rebuild is necessary and
    // calls it if appropriate
    if((count / capacity) > MAX_LOAD){rebuild(); }
}

void StringContactMap::rebuild()
{

}

int StringContactMap::size() const
{
    return count;
}

bool StringContactMap::empty() const
{
    // If map is empty, count is 0
    return count == 0;
}

vector<StringContactPair> StringContactMap::all_contacts() const
{
    // Creating contact pair vector
    vector<StringContactPair> contact_vec;
    for (int i = 0; i < capacity; i++)
    {
        // Pushing list elements to vector
        // repeatedly for each list in map
        if(map[i] != NULL)
        {
            map[i]->add_to_vector(contact_vec);
        }
    }
    // Sort alphabetically, then return
    sort(contact_vec.begin(), contact_vec.end());
    return contact_vec;
}

void StringContactMap::add(string key, Contact value)
{
    // Checks if rebuild is necessary and
    // calls it if appropriate
    load_check();
    // Finds desired index for key
    int index = hash_key(key);
    // If list does not exist at index
    // new list constructed and count increases
    if(map[index] == NULL)
    {
        map[index] = new ContactList();
    }
    // In any case, node is added by key and value in list at index
    // Value changed if entry already present
    if(map[index]->add(key, value))
    {
        count++;
    }
}

void StringContactMap::remove(string key)
{
    // Finds index of map where key should be
    // Action only taken if key is in list at index
    int hased_key = hash_key(key);
    if(map[hased_key] != NULL)
    {
        if (map[hased_key]->contains(key))
        {
            // List removes node with key internally
            // If list at index is emptied, count is lowered
            map[hased_key]->remove(key);
            count--;
        }
    }
}

bool StringContactMap::contains(string key)
{
    // Finds index of map where key should be
    // Returns true if key is in list at index
    int hased_key = hash_key(key);
    if(map[hased_key] == NULL)
    {
        return false;
    }
    else
    {
        return map[hased_key]->contains(key);
    }
}

Contact StringContactMap::get(string key)
{
    // Returns contact value if key is
    // in hash map
    if(contains(key))
    {
        int hased_key = hash_key(key);
        ListPtr clist = map[hased_key];
        return clist->get(key);
    }
    // Otherwise throws an exception
    else
    {
        throw KeyException();
    }
}

vector<Contact> StringContactMap::prefix_search(string prefix) const
{
    return vector <Contact>();
}

int StringContactMap::hash_key(string key)
{
    // uses modulo to get correct value from
    // general hash function to correspond this map
    return hash_value(key) % capacity;
}

void StringContactMap::delete_map(ListPtr *list_map)
{
    // Deletes all the ContactLists in map
    // Then deletes map itself
    for (int i = 0; i < capacity; i++)
    {
        delete list_map[i];
    }
    delete [] list_map;
}

ostream& operator <<(ostream& out, const StringContactMap& map)
{
    // Outputs hash map contacts
    vector<StringContactPair> contacts = map.all_contacts();

    for(size_t i = 0; i < contacts.size(); i++) {
        out << contacts[i].value << endl;
    }
    return out;
}
